<?php
declare(strict_types=1);

namespace hardMOB\Afiliados\Entity;

use XF\Entity\AbstractEntity;
use XF\Mvc\Entity\Structure;

class Store extends AbstractEntity
{
    public static function getStructure(Structure $structure): Structure
    {
        $structure->table = 'xf_afiliados_store';
        $structure->shortName = 'hardMOB\Afiliados:Store';
        $structure->primaryKey = 'store_id';
        $structure->columns = [
            'store_id'        => ['type' => self::UINT, 'autoIncrement' => true],
            'name'            => ['type' => self::STR, 'required' => true, 'maxLength' => 100],
            'domain'          => ['type' => self::STR, 'required' => true, 'maxLength' => 150],
            'affiliate_code'  => ['type' => self::STR, 'required' => true, 'maxLength' => 100],
            'active'          => ['type' => self::UINT, 'default' => 1],
            'date_added'      => ['type' => self::UINT, 'default' => \XF::$time],
        ];

        $structure->getters = [];
        $structure->relations = [];

        return $structure;
    }
}