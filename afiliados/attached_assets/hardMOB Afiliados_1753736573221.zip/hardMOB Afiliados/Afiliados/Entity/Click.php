<?php
declare(strict_types=1);

namespace hardMOB\Afiliados\Entity;

use XF\Entity\AbstractEntity;
use XF\Mvc\Entity\Structure;

class Click extends AbstractEntity
{
    public static function getStructure(Structure $structure): Structure
    {
        $structure->table = 'xf_afiliados_click';
        $structure->shortName = 'hardMOB\Afiliados:Click';
        $structure->primaryKey = 'click_id';
        $structure->columns = [
            'click_id'        => ['type' => self::UINT, 'autoIncrement' => true],
            'store_id'        => ['type' => self::UINT, 'required' => true],
            'path'            => ['type' => self::STR, 'maxLength' => 255],
            'creator_user_id' => ['type' => self::UINT, 'default' => 0],
            'click_user_id'   => ['type' => self::UINT, 'default' => 0],
            'clicked_at'      => ['type' => self::UINT, 'default' => \XF::$time],
        ];

        $structure->relations = [
            'Store' => [
                'entity' => 'hardMOB\Afiliados:Store',
                'type' => self::TO_ONE,
                'conditions' => 'store_id',
                'primary' => true
            ]
        ];

        return $structure;
    }
}