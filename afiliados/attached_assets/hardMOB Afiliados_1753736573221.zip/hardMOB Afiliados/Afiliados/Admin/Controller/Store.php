<?php
declare(strict_types=1);

namespace hardMOB\Afiliados\Admin\Controller;

use XF\Admin\Controller\AbstractController;
use XF\Mvc\ParameterBag;
use XF\Mvc\FormAction;

class Store extends AbstractController
{
    public function actionList()
    {
        $stores = $this->finder('hardMOB\Afiliados:Store')
            ->order('store_id', 'DESC')
            ->fetch();

        $viewParams = [
            'stores' => $stores
        ];

        return $this->view('hardMOB\Afiliados:Store\List', 'afiliados_store_list', $viewParams);
    }
}