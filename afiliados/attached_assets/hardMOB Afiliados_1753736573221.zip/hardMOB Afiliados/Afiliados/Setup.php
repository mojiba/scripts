<?php
declare(strict_types=1);

namespace hardMOB\Afiliados;

use XF\AddOn\AbstractSetup;
use XF\Db\Schema\Create;

class Setup extends AbstractSetup
{
public function install(array $stepParams = [])
{
    \XF::dump(\XF::phrase('option_group.hmaf_afiliados'));
    \XF::dump(\XF::phrase('option_group_description.hmaf_afiliados'));

    $schema = $this->schemaManager();

    // Criação das tabelas
    if (!$schema->tableExists('xf_afiliados_store')) {
        $schema->createTable('xf_afiliados_store', function(Create $table): void {
            $table->addColumn('store_id',        'int')->autoIncrement()->primaryKey();
            $table->addColumn('name',            'varchar', 100);
            $table->addColumn('domain',          'varchar', 150);
            $table->addColumn('affiliate_code',  'varchar', 100);
            $table->addColumn('active',          'tinyint')->setDefault(1);
            $table->addColumn('date_added',      'int')->setDefault(0);
        });
    }

    if (!$schema->tableExists('xf_afiliados_click')) {
        $schema->createTable('xf_afiliados_click', function(Create $table): void {
            $table->addColumn('click_id',        'int')->autoIncrement()->primaryKey();
            $table->addColumn('store_id',        'int');
            $table->addColumn('path',            'varchar', 255);
            $table->addColumn('creator_user_id', 'int')->setDefault(0);
            $table->addColumn('click_user_id',   'int')->setDefault(0);
            $table->addColumn('clicked_at',      'int')->setDefault(0);
            $table->addKey(['store_id']);
            $table->addKey(['creator_user_id']);
            $table->addKey(['click_user_id']);
        });
    }
}

    public function upgrade(array $stepParams = [], array $previousVersion = [])
    {
        return null;
    }

    public function uninstall(array $stepParams = [])
    {
        $schema = $this->schemaManager();
        if ($schema->tableExists('xf_afiliados_click')) {
            $schema->dropTable('xf_afiliados_click');
        }
        if ($schema->tableExists('xf_afiliados_store')) {
            $schema->dropTable('xf_afiliados_store');
        }
        return null;
    }
	
}